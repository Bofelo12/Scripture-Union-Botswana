# ap-scroll-top

jQuery plugin for embedding a "Scroll to Top" element to website, with position fixed.

---

Complete documentation coming soon. Have a look at code of [the example](https://github.com/armin-pfaeffle/ap-scroll-top/blob/master/index.html). Many things are used there.
