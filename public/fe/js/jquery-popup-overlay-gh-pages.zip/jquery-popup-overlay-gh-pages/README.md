# jQuery Popup Overlay

jQuery plugin for responsive and accessible modal windows and tooltips

[![NPM version](https://img.shields.io/npm/v/jquery-popup-overlay.svg?style=flat)](https://www.npmjs.com/package/jquery-popup-overlay)
[![NPM dependencies](https://img.shields.io/david/vast-engineering/jquery-popup-overlay.svg?style=flat)](https://david-dm.org/vast-engineering/jquery-popup-overlay)
[![NPM dev dependencies](https://img.shields.io/david/dev/vast-engineering/jquery-popup-overlay.svg?style=flat)](https://david-dm.org/vast-engineering/jquery-popup-overlay?type=dev)

## Documentation & demo
[Documentation & demo](https://vast-engineering.github.io/jquery-popup-overlay/)

## License
Released under the [MIT license](https://github.com/vast-engineering/jquery-popup-overlay/blob/gh-pages/LICENSE).
